using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowBullet : MonoBehaviour
{
    public float speed;

    private Rigidbody2D mybody;

    private void Awake()
    {
        mybody = GetComponent<Rigidbody2D>();
    }
    private void FixedUpdate()
    {
        mybody.velocity = new Vector2(0f, speed);
    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Enemy")
        {
            Destroy(col.gameObject);
            Destroy(gameObject);
        }
        if (col.tag == "border")
        {
            Destroy(gameObject);
        }
    }
}
