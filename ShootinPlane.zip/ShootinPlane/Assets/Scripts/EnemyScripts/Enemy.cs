using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
   
    public float enemySpeed;

    private Rigidbody2D myBody;

    [SerializeField]
    private GameObject bullet;

    private void Awake()
    {
        myBody = GetComponent<Rigidbody2D>();
    }
    private void FixedUpdate()
    {
        myBody.velocity = new Vector2(0f, -enemySpeed);
    }
    private void Start()
    {
        StartCoroutine(EnemyShoot());
    }
    IEnumerator EnemyShoot()
    {
        yield return new WaitForSeconds(Random.Range(1f, 3f));

        Vector3 temp = transform.position;
        temp.y -= 0.5f;
        Instantiate(bullet, temp, Quaternion.identity);

        StartCoroutine(EnemyShoot());
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if(col.tag == "Player")
        {
            Destroy(col.gameObject);
            GamePlayController.instance.PlaneDiedShowPanel();
        }
        if(col.tag == "border")
        {
            Destroy(gameObject);
        }
    }
}
